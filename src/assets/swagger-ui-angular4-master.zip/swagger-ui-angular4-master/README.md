# Swagger UI with Angular4

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 1.3.0.

It was originally generated as a bug example app, later being adapted as an example of how to integrate Swagger-UI (Original repository: [asakalou/swagger-angular4-issue](https://github.com/asakalou/swagger-angular4-issue)).

Both the CLI and generated project have dependencies that require Node 6.9.0 or higher, together with NPM 3 or higher.

# Start the project

Run `npm install` and `ng serve`. Server will start at port 4200. Go to [localhost:4200](localhost:4200).
